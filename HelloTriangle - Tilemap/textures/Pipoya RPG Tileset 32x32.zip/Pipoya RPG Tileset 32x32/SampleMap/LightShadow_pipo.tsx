<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="LightShadow_pipo" tilewidth="32" tileheight="32" tilecount="48" columns="8" backgroundcolor="#005500">
 <image source="LightShadow_pipo.png" width="256" height="192"/>
</tileset>
